package com.ark.bookingapp.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ark.bookingapp.databinding.RoomItemListBinding
import com.ark.bookingapp.model.roomItemModel


class roomListRecyclerViewAdapter(var roomList: List<roomItemModel>) : RecyclerView.Adapter<roomListRecyclerViewAdapter.MyViewHolder>() {


    inner class MyViewHolder(val binding: RoomItemListBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {

            val binding = RoomItemListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        with(holder){
            with(roomList[position]){
                binding.mainImg.setImageResource(this.mainImg)
                binding.price1.setText(this.price1)
                binding.price2.setText( this.price2)
                binding.tvAddress.setText(this.address)
                binding.tvTitle.setText(this.title)
            }
        }

    }

    override fun getItemCount(): Int {
        return roomList.size
    }
}