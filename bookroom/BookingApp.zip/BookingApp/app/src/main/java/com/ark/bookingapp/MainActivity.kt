package com.ark.bookingapp

import android.R
import android.content.res.loader.ResourcesLoader
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ark.bookingapp.adapter.roomListRecyclerViewAdapter
import com.ark.bookingapp.databinding.ActivityMainBinding
import com.ark.bookingapp.model.roomItemModel


class MainActivity : AppCompatActivity() {


    lateinit var binding: ActivityMainBinding
//    lateinit var viewModel : MyViewModel
    lateinit var roomList : List<roomItemModel>

    lateinit var roomAdapter: roomListRecyclerViewAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)

        var binding: ActivityMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        getSupportActionBar()!!.hide();




            roomList = listOf(
//                roomItemModel("Java" , R.drawable.ic_launcher_back,R.drawable.arrow_down_float,"kharadi, pune","234","234"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),
                roomItemModel("Java" , R.drawable.ic_btn_speak_now,R.drawable.ic_btn_speak_now,"kharadi, pune","$123","$420"),


//                roomItemModel("Java" , R.drawable.ic_launcher_background,R.drawable.ic_launcher_background,"kharadi, pune",123,420),
//                roomItemModel("Java" , R.drawable.ic_launcher_background,R.drawable.ic_launcher_background,"kharadi, pune",123,420),
//                roomItemModel("Java" , R.drawable.ic_launcher_background,R.drawable.ic_launcher_background,"kharadi, pune",123,420),
//                roomItemModel("Java" , R.drawable.ic_launcher_background,R.drawable.ic_launcher_background,"kharadi, pune",123,420),
//                roomItemModel("Java" , R.drawable.ic_launcher_background,R.drawable.ic_launcher_background,"kharadi, pune",123,420),
//                roomItemModel("Java" , R.drawable.ic_launcher_background,R.drawable.ic_launcher_background,"kharadi, pune",123,420),
//                roomItemModel("Java" , R.drawable.ic_launcher_background,R.drawable.ic_launcher_background,"kharadi, pune",123,420),
//                roomItemModel("Java" , R.drawable.ic_launcher_background,R.drawable.ic_launcher_background,"kharadi, pune",123,420),
//                roomItemModel("Java" , R.drawable.ic_launcher_background,R.drawable.ic_launcher_background,"kharadi, pune",123,420),
//                roomItemModel("Java" , R.drawable.ic_launcher_background,R.drawable.ic_launcher_background,"kharadi, pune",123,420),
//                roomItemModel("Java" , R.drawable.ic_launcher_background,R.drawable.ic_launcher_background,"kharadi, pune",123,420),
//                roomItemModel("Java" , R.drawable.ic_launcher_background,R.drawable.ic_launcher_background,"kharadi, pune",123,420),
            )


        roomAdapter = roomListRecyclerViewAdapter(roomList)
        binding.recyclerView.setAdapter(roomAdapter)
        binding.recyclerView.setLayoutManager(
            LinearLayoutManager(this)
        )
//        val navHostFragment = supportFragmentManager
//            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
//        navController = navHostFragment.navController
//
//        viewModel = ViewModelProvider(this).get(MyViewModel::class.java)









    }
}