package com.ark.bookingapp.model

import android.graphics.drawable.Drawable

data class roomItemModel(
    val title: String, val mainImg: Int, val likeImg: Int,
    val address:String, val price1:String, val price2:String)
